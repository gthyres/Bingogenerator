"""
bingo_core.py

Generator-logik för bingospelplaner (9 x 3, 5 siffror per rad, 6 spelplaner per
liggande A4, varje siffra 1-90 exakt en gång per A4).

Används av bingo_gui.py men kan även köras fristående:
    python bingo_core.py
"""

import itertools
import random

from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas

TICKETS_PER_PAGE = 6
ROWS = 3
COLS = 9

PAGE_W, PAGE_H = landscape(A4)

COL_RANGES = [
    list(range(1, 10)),
    list(range(10, 20)),
    list(range(20, 30)),
    list(range(30, 40)),
    list(range(40, 50)),
    list(range(50, 60)),
    list(range(60, 70)),
    list(range(70, 80)),
    list(range(80, 91)),
]

COLUMN_TARGETS = [9, 10, 10, 10, 10, 10, 10, 10, 11]
ALL_ROW_PATTERNS = list(itertools.combinations(range(COLS), 5))


class Cancelled(Exception):
    """Kastas när användaren avbryter genereringen."""


def make_page_masks():
    """Slumpa fram vilka rutor som ska innehålla siffror (loop i stället för rekursion)."""
    total_rows = TICKETS_PER_PAGE * ROWS

    while True:
        targets = COLUMN_TARGETS[:]
        rows = []
        failed = False

        for row_index in range(total_rows):
            rows_left_after = total_rows - row_index - 1
            possible = []

            for pattern in ALL_ROW_PATTERNS:
                new_targets = targets[:]
                ok = True
                for c in pattern:
                    if new_targets[c] <= 0:
                        ok = False
                        break
                    new_targets[c] -= 1
                if ok and all(x <= rows_left_after for x in new_targets):
                    possible.append(pattern)

            if not possible:
                failed = True
                break

            weights = [sum(targets[c] for c in p) for p in possible]
            chosen = random.choices(possible, weights=weights, k=1)[0]
            rows.append(chosen)
            for c in chosen:
                targets[c] -= 1

        if failed or targets != [0] * COLS:
            continue

        masks = []
        index = 0
        for _ in range(TICKETS_PER_PAGE):
            ticket = [[0] * COLS for _ in range(ROWS)]
            for r in range(ROWS):
                for c in rows[index]:
                    ticket[r][c] = 1
                index += 1
            masks.append(ticket)
        return masks


def fill_numbers(masks):
    tickets = [
        [["" for _ in range(COLS)] for _ in range(ROWS)]
        for _ in range(TICKETS_PER_PAGE)
    ]

    for c in range(COLS):
        nums = COL_RANGES[c][:]
        random.shuffle(nums)

        cells = [
            (t, r)
            for t in range(TICKETS_PER_PAGE)
            for r in range(ROWS)
            if masks[t][r][c]
        ]

        if len(cells) != len(nums):
            raise ValueError("Fel antal rutor i kolumn")

        for (t, r), n in zip(cells, nums):
            tickets[t][r][c] = str(n)

    return tickets


def check_page(tickets):
    numbers = []
    for ticket in tickets:
        for row in ticket:
            if sum(1 for x in row if x) != 5:
                return False
            numbers.extend(int(x) for x in row if x)
    return sorted(numbers) == list(range(1, 91))


def draw_ticket(pdf, grid, x0, y0, w, h, serial, title="B I N G O", show_serial=True):
    header_h = 10 * mm
    grid_h = h - header_h
    cell_w = w / COLS
    cell_h = grid_h / ROWS

    pdf.setLineWidth(2.2)
    pdf.rect(x0, y0, w, h)

    if show_serial:
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawString(x0 + 2 * mm, y0 + h - 6 * mm, f"{serial:06d}")

    pdf.setFont("Helvetica-Bold", 24)
    pdf.drawCentredString(x0 + w / 2, y0 + h - 8 * mm, title)

    pdf.line(x0, y0 + grid_h, x0 + w, y0 + grid_h)

    for r in range(ROWS):
        for c in range(COLS):
            x = x0 + c * cell_w
            y = y0 + (ROWS - 1 - r) * cell_h

            pdf.setLineWidth(1.8)
            pdf.rect(x, y, cell_w, cell_h)

            value = grid[r][c]
            if value:
                pdf.setFont("Helvetica-Bold", 22)
                pdf.drawCentredString(x + cell_w / 2, y + cell_h / 2 - 3.5 * mm, value)


def draw_page(pdf, tickets, page_number, first_serial, title="B I N G O",
              show_serial=True, show_page_label=True):
    if show_page_label:
        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawString(5 * mm, PAGE_H - 7 * mm, f"A4 {page_number:04d}")

    margin_x = 4 * mm
    margin_y = 4 * mm
    gap_x = 4 * mm
    gap_y = 4 * mm

    ticket_w = (PAGE_W - 2 * margin_x - gap_x) / 2
    ticket_h = (PAGE_H - 2 * margin_y - 2 * gap_y) / 3

    positions = []
    for row in range(3):
        for col in range(2):
            x = margin_x + col * (ticket_w + gap_x)
            y = PAGE_H - margin_y - (row + 1) * ticket_h - row * gap_y
            positions.append((x, y))

    for i, (x, y) in enumerate(positions):
        draw_ticket(pdf, tickets[i], x, y, ticket_w, ticket_h,
                    first_serial + i, title=title, show_serial=show_serial)


def generate_pdf(output_file, total_pages=500, first_serial=1, title="B I N G O",
                 seed=None, show_serial=True, show_page_label=True,
                 progress=None, cancelled=None):
    """
    Skapar PDF-filen.

    progress(done, total)  anropas efter varje sida.
    cancelled()            returnerar True om användaren avbrutit.
    """
    if seed is not None:
        random.seed(seed)

    pdf = canvas.Canvas(output_file, pagesize=landscape(A4))
    pdf.setTitle("Bingospelplaner")
    seen_pages = set()
    serial = first_serial

    for page_number in range(1, total_pages + 1):
        while True:
            if cancelled and cancelled():
                raise Cancelled()

            masks = make_page_masks()
            tickets = fill_numbers(masks)

            if not check_page(tickets):
                continue

            key = tuple(tuple(tuple(row) for row in t) for t in tickets)
            if key not in seen_pages:
                seen_pages.add(key)
                break

        draw_page(pdf, tickets, page_number, serial, title=title,
                  show_serial=show_serial, show_page_label=show_page_label)
        serial += TICKETS_PER_PAGE
        pdf.showPage()

        if progress:
            progress(page_number, total_pages)

    pdf.save()
    return output_file


if __name__ == "__main__":
    generate_pdf(
        "bingo_500_A4_6_spelplaner.pdf",
        progress=lambda d, t: print(f"Skapade {d} av {t} sidor") if d % 25 == 0 else None,
    )
    print("Klar")
