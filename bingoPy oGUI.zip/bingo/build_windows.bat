@echo off
REM Bygger Bingogenerator.exe (PyInstaller) och sedan installationsprogrammet (Inno Setup).
REM Krav pa BYGGDATORN (inte pa slutanvandarens dator): Python 3.10+ och Inno Setup 6.

python -m pip install --upgrade pip
python -m pip install reportlab pyinstaller
if errorlevel 1 exit /b 1

python -m PyInstaller --noconfirm --clean --onedir --windowed --name Bingogenerator bingo_gui.py
if errorlevel 1 exit /b 1

set ISCC="%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist %ISCC% set ISCC="%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist %ISCC% (
  echo Inno Setup 6 hittades inte. Installera fran https://jrsoftware.org/isinfo.php
  exit /b 1
)
%ISCC% installer.iss
echo.
echo Klart! Installationsprogrammet ligger i mappen "installer_output".
