"""
bingo_gui.py - Grafiskt gränssnitt för bingogeneratorn (Tkinter).
"""

import os
import queue
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import bingo_core

APP_NAME = "Bingogenerator"
SERIAL_NOTE = "Spelplansnummer fortsätter från startnumret, 6 per sida."


def open_file(path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # noqa: S606
        elif sys.platform == "darwin":
            os.system(f'open "{path}"')
        else:
            os.system(f'xdg-open "{path}"')
    except Exception:
        pass


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.resizable(False, False)

        self.msgs = queue.Queue()
        self.cancel_flag = threading.Event()
        self.worker = None
        self.start_time = 0.0

        default_out = os.path.join(
            os.path.expanduser("~"), "Documents", "bingo_spelplaner.pdf"
        )
        if not os.path.isdir(os.path.dirname(default_out)):
            default_out = os.path.join(os.path.expanduser("~"), "bingo_spelplaner.pdf")

        self.var_pages = tk.StringVar(value="500")
        self.var_serial = tk.StringVar(value="1")
        self.var_title = tk.StringVar(value="B I N G O")
        self.var_seed = tk.StringVar(value="")
        self.var_out = tk.StringVar(value=default_out)
        self.var_show_serial = tk.BooleanVar(value=True)
        self.var_show_label = tk.BooleanVar(value=True)
        self.var_open = tk.BooleanVar(value=True)
        self.var_info = tk.StringVar(value="")
        self.var_status = tk.StringVar(value="Redo.")

        self._build()
        self.var_pages.trace_add("write", lambda *_: self._update_info())
        self.var_serial.trace_add("write", lambda *_: self._update_info())
        self._update_info()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------- UI ----------
    def _build(self):
        pad = {"padx": 8, "pady": 4}
        frm = ttk.Frame(self, padding=14)
        frm.grid(sticky="nsew")

        ttk.Label(frm, text="Bingospelplaner", font=("TkDefaultFont", 14, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 8)
        )

        ttk.Label(frm, text="Antal A4-sidor:").grid(row=1, column=0, sticky="w", **pad)
        ttk.Spinbox(frm, from_=1, to=5000, textvariable=self.var_pages, width=10).grid(
            row=1, column=1, sticky="w", **pad
        )

        ttk.Label(frm, text="Startnummer:").grid(row=2, column=0, sticky="w", **pad)
        ttk.Spinbox(frm, from_=1, to=9999999, textvariable=self.var_serial, width=10).grid(
            row=2, column=1, sticky="w", **pad
        )

        ttk.Label(frm, text="Rubrik på spelplan:").grid(row=3, column=0, sticky="w", **pad)
        ttk.Entry(frm, textvariable=self.var_title, width=24).grid(
            row=3, column=1, columnspan=2, sticky="w", **pad
        )

        ttk.Label(frm, text="Slumpfrö (valfritt):").grid(row=4, column=0, sticky="w", **pad)
        ttk.Entry(frm, textvariable=self.var_seed, width=14).grid(
            row=4, column=1, sticky="w", **pad
        )
        ttk.Label(frm, text="samma frö = samma resultat", foreground="#666").grid(
            row=4, column=2, sticky="w"
        )

        ttk.Label(frm, text="Spara som:").grid(row=5, column=0, sticky="w", **pad)
        ttk.Entry(frm, textvariable=self.var_out, width=46).grid(
            row=5, column=1, columnspan=2, sticky="we", **pad
        )
        ttk.Button(frm, text="Bläddra…", command=self._browse).grid(row=5, column=3, **pad)

        opts = ttk.Frame(frm)
        opts.grid(row=6, column=0, columnspan=4, sticky="w", pady=(4, 0))
        ttk.Checkbutton(opts, text="Skriv ut spelplansnummer", variable=self.var_show_serial).pack(
            anchor="w", padx=8
        )
        ttk.Checkbutton(opts, text="Skriv ut sidnummer (A4 0001)", variable=self.var_show_label).pack(
            anchor="w", padx=8
        )
        ttk.Checkbutton(opts, text="Öppna PDF när den är klar", variable=self.var_open).pack(
            anchor="w", padx=8
        )

        ttk.Label(frm, textvariable=self.var_info, foreground="#444").grid(
            row=7, column=0, columnspan=4, sticky="w", padx=8, pady=(8, 2)
        )

        self.bar = ttk.Progressbar(frm, length=440, mode="determinate")
        self.bar.grid(row=8, column=0, columnspan=4, padx=8, pady=(6, 2), sticky="we")
        ttk.Label(frm, textvariable=self.var_status).grid(
            row=9, column=0, columnspan=4, sticky="w", padx=8
        )

        btns = ttk.Frame(frm)
        btns.grid(row=10, column=0, columnspan=4, sticky="e", pady=(10, 0))
        self.btn_go = ttk.Button(btns, text="Skapa PDF", command=self._start)
        self.btn_go.pack(side="left", padx=4)
        self.btn_cancel = ttk.Button(btns, text="Avbryt", command=self._cancel, state="disabled")
        self.btn_cancel.pack(side="left", padx=4)
        ttk.Button(btns, text="Stäng", command=self._on_close).pack(side="left", padx=4)

    # ---------- helpers ----------
    def _int(self, var, name, lo, hi):
        try:
            v = int(var.get())
        except ValueError:
            raise ValueError(f"{name} måste vara ett heltal.")
        if not lo <= v <= hi:
            raise ValueError(f"{name} måste vara mellan {lo} och {hi}.")
        return v

    def _update_info(self):
        try:
            pages = int(self.var_pages.get())
            first = int(self.var_serial.get())
            n = pages * bingo_core.TICKETS_PER_PAGE
            self.var_info.set(
                f"{n} spelplaner, nummer {first:06d}–{first + n - 1:06d}."
            )
        except ValueError:
            self.var_info.set("")

    def _browse(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF", "*.pdf")],
            initialfile=os.path.basename(self.var_out.get()) or "bingo_spelplaner.pdf",
            initialdir=os.path.dirname(self.var_out.get()) or None,
        )
        if path:
            self.var_out.set(path)

    # ---------- run ----------
    def _start(self):
        try:
            pages = self._int(self.var_pages, "Antal sidor", 1, 5000)
            serial = self._int(self.var_serial, "Startnummer", 1, 9999999)
            seed_txt = self.var_seed.get().strip()
            seed = int(seed_txt) if seed_txt else None
        except ValueError as e:
            messagebox.showerror(APP_NAME, str(e) if "måste" in str(e) else "Slumpfrö måste vara ett heltal.")
            return

        out = self.var_out.get().strip()
        if not out:
            messagebox.showerror(APP_NAME, "Välj var filen ska sparas.")
            return
        if not out.lower().endswith(".pdf"):
            out += ".pdf"
            self.var_out.set(out)
        if os.path.exists(out) and not messagebox.askyesno(
            APP_NAME, "Filen finns redan. Vill du skriva över den?"
        ):
            return

        opts = dict(
            output_file=out,
            total_pages=pages,
            first_serial=serial,
            title=self.var_title.get() or "B I N G O",
            seed=seed,
            show_serial=self.var_show_serial.get(),
            show_page_label=self.var_show_label.get(),
        )

        self.cancel_flag.clear()
        self.bar.configure(maximum=pages, value=0)
        self.btn_go.configure(state="disabled")
        self.btn_cancel.configure(state="normal")
        self.var_status.set("Startar…")
        self.start_time = time.time()

        self.worker = threading.Thread(target=self._run, args=(opts,), daemon=True)
        self.worker.start()
        self.after(100, self._poll)

    def _run(self, opts):
        try:
            bingo_core.generate_pdf(
                progress=lambda d, t: self.msgs.put(("progress", d, t)),
                cancelled=self.cancel_flag.is_set,
                **opts,
            )
            self.msgs.put(("done", opts["output_file"]))
        except bingo_core.Cancelled:
            try:
                if os.path.exists(opts["output_file"]):
                    os.remove(opts["output_file"])
            except OSError:
                pass
            self.msgs.put(("cancelled",))
        except Exception as e:  # noqa: BLE001
            self.msgs.put(("error", str(e)))

    def _poll(self):
        finished = False
        try:
            while True:
                m = self.msgs.get_nowait()
                if m[0] == "progress":
                    done, total = m[1], m[2]
                    self.bar.configure(value=done)
                    el = time.time() - self.start_time
                    eta = el / done * (total - done) if done else 0
                    self.var_status.set(f"Sida {done} av {total} – ca {int(eta)} s kvar")
                elif m[0] == "done":
                    finished = True
                    self.var_status.set("Klar!")
                    messagebox.showinfo(APP_NAME, f"PDF skapad:\n{m[1]}")
                    if self.var_open.get():
                        open_file(m[1])
                elif m[0] == "cancelled":
                    finished = True
                    self.var_status.set("Avbruten.")
                elif m[0] == "error":
                    finished = True
                    self.var_status.set("Fel.")
                    messagebox.showerror(APP_NAME, f"Något gick fel:\n{m[1]}")
        except queue.Empty:
            pass

        if finished:
            self.btn_go.configure(state="normal")
            self.btn_cancel.configure(state="disabled")
        else:
            self.after(100, self._poll)

    def _cancel(self):
        self.cancel_flag.set()
        self.var_status.set("Avbryter…")

    def _on_close(self):
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno(APP_NAME, "Genereringen pågår. Avbryta och stänga?"):
                return
            self.cancel_flag.set()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
