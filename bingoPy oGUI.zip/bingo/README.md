# Bingogenerator

Grafiskt program som skapar bingospelplaner som PDF (6 spelplaner per liggande A4,
9 x 3 rutor, varje siffra 1-90 exakt en gång per A4).

## Filer

| Fil | Syfte |
|---|---|
| `bingo_core.py` | Generatorlogiken (från din ursprungliga `bingo_generator.py`) |
| `bingo_gui.py` | Grafiskt gränssnitt (Tkinter) |
| `build_windows.bat` | Bygger `.exe` med PyInstaller och installationsprogram med Inno Setup |
| `installer.iss` | Inno Setup-skript |
| `.github/workflows/build.yml` | Bygger installationsprogrammet automatiskt på GitHub (om du inte vill installera något själv) |

## Bygga installationsprogrammet (Windows)

Slutanvändaren behöver **inte** Python. Python behövs bara på den dator där du bygger.

**Alternativ A – på din egen Windows-dator**
1. Installera Python 3.10+ (https://python.org) och Inno Setup 6 (https://jrsoftware.org/isinfo.php).
2. Dubbelklicka `build_windows.bat` i den här mappen.
3. Färdigt installationsprogram: `installer_output\Bingogenerator_Setup.exe`

**Alternativ B – via GitHub (inget behöver installeras lokalt)**
1. Lägg mappen i ett GitHub-repo.
2. Öppna fliken *Actions* > *Build Windows installer* > *Run workflow*.
3. Ladda ner `Bingogenerator_Setup` under *Artifacts*.

Installationsprogrammet installerar för den aktuella användaren (ingen administratör krävs),
skapar Startmenygenväg och valfri skrivbordsgenväg samt avinstallerare.

## Köra utan att bygga
```
pip install reportlab
python bingo_gui.py
```
