@echo off
REM Bygger en portabel Bingogenerator.exe (en enda fil) som kan kopieras till ett USB-minne.
REM Krav pa BYGGDATORN: Python 3.10+. Slutanvandaren behover inget.

python -m pip install --upgrade pip
python -m pip install reportlab pyinstaller
if errorlevel 1 exit /b 1

python -m PyInstaller --noconfirm --clean --onefile --windowed --name Bingogenerator bingo_gui.py
if errorlevel 1 exit /b 1

echo.
echo Klart! Kopiera dist\Bingogenerator.exe till USB-minnet och dubbelklicka for att starta.
